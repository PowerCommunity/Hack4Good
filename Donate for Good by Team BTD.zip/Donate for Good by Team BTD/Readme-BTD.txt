Read Me: (Kindly open all videos in the windows media player as there seems to be an issue in viewing properly in VLC)

This solution consists of MS Forms, PVA and portals as well. As those cannot be attached here, the credentials below can be used to view the same. 

The environment to be logged into is bythedevs (bythedevs).

PVA URL: https://powerva.microsoft.com/canvas?cci_bot_id=5448187d-1f60-412b-bd67-b83cb1cd52ef&cci_tenant_id=e3754a51-a790-4271-97db-1c244a35702f

Portal URL: https://donateforgood.powerappsportals.com/

Full video URL: https://www.loom.com/share/59fad9f229444e74bd77af7a9dec01df (went above 5 mins but covers the entire solution)


Credential to login for Power Virtual Agent
UsrName: yash@bythedevs.onmicrosoft.com
Pass: Test@1234

Credential to login for the Portal
UsrName: ritika@bythedevs.onmicrosoft.com
Pass: Vansh@5628

We have attached the 
1. Managed and unmanaged solution (contains the entities, model driven app, flows used in the PVA)
2. Flow to create records based on Form responses
3. Flow to add lat long when record is created from MDA or Portal
4. Flow to add a picture to the entity record
5. PBIX file for the PowerBI Report
6. Presentation 
7. Video demonstration