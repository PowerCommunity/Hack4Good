Credentials:
Kapil@MADHackers.onmicrosoft.com
Dipen@MADHackers.onmicrosoft.com
Anupriya@MADHackers.onmicrosoft.com
Rachit@MADHackers.onmicrosoft.com
Srujana@MADHackers.onmicrosoft.com
Pwd:
HackMad@123

SharePoint List: Our Patient data repository
https://madhackers.sharepoint.com/sites/MADHackers/Lists/PatientData

PowerApp: Our Application [Rapid Response Application]
https://apps.powerapps.com/play/1232eb69-e3a1-45c4-be09-0dc8584cebcf

PowerBi Report:
https://app.powerbi.com/groups/aa73e437-2a49-44a1-acd4-d4510438e762/reports/04453123-294d-41d6-9318-8cbe62aa294f/ReportSection

Total 3 flows exist: Open the link and go to Team Flows to see existing flows being used
https://make.powerapps.com/environments/cc4c2f9e-7bc5-4284-9ee3-21ec7ad328f0/logicflows

YouTube Video:
https://youtu.be/rNi2zEgi_Jg

The Manifest file of PowerApp and all the associated workflows is also attached in Folder along with PowerBi Report

